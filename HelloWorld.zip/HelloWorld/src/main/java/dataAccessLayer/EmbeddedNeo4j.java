/**
 * 
 */
package dataAccessLayer;

import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.neo4j.driver.Transaction;
import org.neo4j.driver.TransactionWork;

import static org.neo4j.driver.Values.parameters;

import java.util.LinkedList;
import java.util.List;
/**
 * @author Administrator
 *
 */
public class EmbeddedNeo4j implements AutoCloseable{

    private final Driver driver;
    

    public EmbeddedNeo4j( String uri, String user, String password )
    {
        driver = GraphDatabase.driver( uri, AuthTokens.basic( user, password ) );
    }

    @Override
    public void close() throws Exception
    {
        driver.close();
    }

    public void printGreeting( final String message )
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
                    Result result = tx.run( "CREATE (a:Greeting) " +
                                                     "SET a.message = $message " +
                                                     "RETURN a.message + ', from node ' + id(a)",
                            parameters( "message", message ) );
                    return result.single().get( 0 ).asString();
                }
            } );
            System.out.println( greeting );
        }
    }
    
    public LinkedList<String> getJuegos()
    {
    	 try ( Session session = driver.session() )
         {
    		 
    		 
    		 LinkedList<String> Videojuegos = session.readTransaction( new TransactionWork<LinkedList<String>>()
             {
                 @Override
                 public LinkedList<String> execute( Transaction tx )
                 {
                     Result result = tx.run( "MATCH (n:Videojuego) RETURN n.Nombre" );
                     LinkedList<String> misVideojuegos = new LinkedList<String>();
                     List<Record> registros = result.list();
                     for (int i = 0; i < registros.size(); i++) {
                    	 //myactors.add(registros.get(i).toString());
                    	 misVideojuegos.add(registros.get(i).get("n.Nombre").asString());
                     }
                     
                     return misVideojuegos;
                 }
             } );
             
             return Videojuegos;
         }
    }
    
    public LinkedList<String> getJuegoPorCategoria(String Edad,String Multi,String Gen1,String Gen2,String Gen3)
    {
   	 try ( Session session = driver.session() )
        {
   		 
   		 
   		 LinkedList<String> Juegos = session.readTransaction( new TransactionWork<LinkedList<String>>()
            {
                @Override
                public LinkedList<String> execute( Transaction tx )
                {
                    Result result = tx.run( "MATCH  (n:Videojuego) - [:Pertenece] -> (m:UnJugador) - [:Pertenece] -> (c:Edad {Nombre:\"" + Edad + "\"}) WHERE n.Gen1 = \"" + Gen1 + "\" AND  n.Gen2 = \"" + Gen2 + "\" OR n.Gen2 = \"" + Gen2 + "\" AND  n.Gen1 =\"" + Gen1 + "\" OR n.Gen2 =\"" + Gen2 + "\" AND  n.Gen3 =\"" + Gen3 + "\" OR n.Gen3 =\"" + Gen3 + "\" AND  n.Gen2 =\"" + Gen2 + "\" OR n.Gen1 =\"" + Gen1 + "\" AND  n.Gen3 =\"" + Gen3 + "\" OR n.Gen3 =\"" + Gen3 + "\" AND  n.Gen1 =\"" + Gen1 + "\" RETURN n.Nombre");
                    LinkedList<String> misJuegos = new LinkedList<String>();
                    List<Record> registros = result.list();
                    for (int i = 0; i < registros.size(); i++) {
                   	 //myactors.add(registros.get(i).toString());
                   	 misJuegos.add(registros.get(i).get("n.Nombre").asString());
                    }
                    
                    return misJuegos;
                }
            } );
            
            return Juegos;
        }
   }
   
   public String getUsuario(String Nombre)
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		String Juegos = session.readTransaction( new TransactionWork<String>()
           {
               @Override
               public String execute( Transaction tx )
               {
            	   Result result = tx.run( "MATCH (n:Persona{Nombre:\"" + Nombre+ "\"})RETURN n");
                   String valor = "0";
                   List<Record> registros = result.list();
                   if(registros.size()==0) {
                	   valor = "0";
                   }
                   else {valor = "1";}
                   
                   return valor;
               }
           } );
           
           return Juegos;
       }
   }
   
   public String CrearUsuario(String Nombre,String Correo,String NombreJuego,String Gen)
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		String Juegos = session.writeTransaction( new TransactionWork<String>()
           {
               @Override
               public String execute( Transaction tx )
               {
            	   tx.run( "CREATE (" + Nombre + ":Persona {Nombre:\"" + Nombre + "\", Correo:\"" + Correo + "\"})");
            	   tx.run( "MATCH (n:Persona {Nombre:\"" + Nombre +"\" })CREATE (" + NombreJuego + ":Videojuego{Nombre:\"" + NombreJuego + "\",Gen:\"" + Gen + "\"})CREATE (" + NombreJuego + ") - [:Pertenece] -> (n)");
               
                   
                   return null;
               }
           } );
           
           return Juegos;
       }
   }
   
   public String getJuego(String Nombre,String NombreJuego)
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		String Juegos = session.readTransaction( new TransactionWork<String>()
           {
               @Override
               public String execute( Transaction tx )
               {
            	   String mensaje = "";
            	   Result result = tx.run( "MATCH (n:Videojuego{Nombre:\""+ NombreJuego +"\"}) - [:Pertenece] -> ("+ Nombre + ":Persona)RETURN n");
            	   
                   List<Record> juegosxUsuario = result.list();
                   if (juegosxUsuario.size() == 0) {
                	   mensaje = "0";
                   }
                   
                   else {mensaje = "1";}
                   return mensaje;
               }
           } );
           
           return Juegos;
       }
   }
   
   public String CrearJuego(String Nombre,String NombreJuego,String Gen)
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		String Juegos = session.writeTransaction( new TransactionWork<String>()
           {
               @Override
               public String execute( Transaction tx )
               {
            	   
            	   tx.run( "MATCH (n:Persona {Nombre:\"" + Nombre +"\" })CREATE (" + NombreJuego + ":Videojuego{Nombre:\"" + NombreJuego + "\",Gen:\"" + Gen + "\"})CREATE (" + NombreJuego + ") - [:Pertenece] -> (n)");
               
                   
                   return null;
               }
           } );
           
           return Juegos;
       }
   }
   
   public LinkedList<String> getJuegosxUsuario(String Nombre)
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		 LinkedList<String> Juegos = session.readTransaction( new TransactionWork<LinkedList<String>>()
           {
               @Override
               public LinkedList<String> execute( Transaction tx )
               {
                   Result result = tx.run( "MATCH (n:Videojuego) - [:Pertenece] -> ("+ Nombre + ":Persona) WHERE " + Nombre + ".Nombre = \"" + Nombre + "\" RETURN n.Nombre");
                   Result resultGen = tx.run( "MATCH (n:Videojuego) - [:Pertenece] -> ("+ Nombre + ":Persona) WHERE " + Nombre + ".Nombre = \"" + Nombre + "\" RETURN n.Gen");
                   LinkedList<String> misJuegos = new LinkedList<String>();
                   List<Record> registros = result.list();
                   List<Record> registrosGen = resultGen.list();
                   for (int i = 0; i < registros.size(); i++) {
                  	 //myactors.add(registros.get(i).toString());
                  	 misJuegos.add(registros.get(i).get("n.Nombre").asString());
                  	 misJuegos.add(registrosGen.get(i).get("n.Gen").asString());
                   }
                   
                   return misJuegos;
               }
           } );
           
           return Juegos;
       }
  }
   
   public LinkedList<String> getTodosLosUsuarios()
   {
  	 try ( Session session = driver.session() )
       {
  		 
  		 
  		 LinkedList<String> Juegos = session.readTransaction( new TransactionWork<LinkedList<String>>()
           {
               @Override
               public LinkedList<String> execute( Transaction tx )
               {
                   Result result = tx.run( "MATCH (n:Persona) RETURN n.Nombre");
                   Result resultCorreo = tx.run( "MATCH (n:Persona) RETURN n.Correo");
                   LinkedList<String> misJuegos = new LinkedList<String>();
                   List<Record> registros = result.list();
                   List<Record> registrosCorreo = resultCorreo.list();
                   for (int i = 0; i < registros.size(); i++) {
                  	 //myactors.add(registros.get(i).toString());
                  	 misJuegos.add(registros.get(i).get("n.Nombre").asString());
                  	 misJuegos.add(registrosCorreo.get(i).get("n.Correo").asString());
                   }
                   
                   return misJuegos;
               }
           } );
           
           return Juegos;
       }
  }

}
