

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import dataAccessLayer.EmbeddedNeo4j;

/**
 * Servlet implementation class AgregarJuego
 */
@WebServlet("/AgregarJuego")
public class AgregarJuego extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AgregarJuego() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				JSONObject myResponse = new JSONObject();
				
				JSONArray nombreVideojuegos = new JSONArray();
				
				String Nombre = request.getParameter("nombre").trim();
				String Correo = request.getParameter("correo").trim();
				String NombreJuego = request.getParameter("nombrejuego").trim();
				String Gen = request.getParameter("gen").trim();
				
				
				try ( EmbeddedNeo4j greeter = new EmbeddedNeo4j( "bolt://localhost:7687", "neo4j", "Test1234" ) )
				{
					if(NombreJuego.equals("") || Gen.equals("")) {
						LinkedList<String> misVideojuegos = greeter.getJuegosxUsuario(Nombre);
						
						for (int i = 0; i < misVideojuegos.size(); i++) {
								//out.println( "<p>" + myactors.get(i) + "</p>" );
							nombreVideojuegos.add(misVideojuegos.get(i));
						}
						
						
					}
					
					else {
						String Existe = greeter.getUsuario(Nombre);
						
						if (Existe.equals("0")) {
							greeter.CrearUsuario(Nombre, Correo, NombreJuego, Gen);
						}
						
						else {
							
							String existeJuego = greeter.getJuego(Nombre, NombreJuego);
							
							if(existeJuego.equals("0")) {
								//El Juego no existe se agrega
								greeter.CrearJuego(Nombre, Correo, NombreJuego, Gen);
								
							}
							
							else {
								//El juego ya existe no se hace nada
								
							}
							
						}
						
						LinkedList<String> misVideojuegos = greeter.getJuegosxUsuario(Nombre);
						
						for (int i = 0; i < misVideojuegos.size(); i++) {
								//out.println( "<p>" + myactors.get(i) + "</p>" );
							nombreVideojuegos.add(misVideojuegos.get(i));
						}
						
						
					}
					
				
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				
				
				myResponse.put("conteo", nombreVideojuegos.size()); //Guardo la cantidad de juegos
				myResponse.put("VideojuegoComunidad", nombreVideojuegos);
				out.println(myResponse);
				out.flush();
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
